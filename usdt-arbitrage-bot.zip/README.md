# 🤖 USDT Arbitrage Bot

Este bot monitora oportunidades de arbitragem de USDT entre as corretoras Binance, KuCoin, Mexc e Bitget.

## ⚙️ Como usar

1. Instale as dependências:
```bash
npm install
```

2. Inicie o bot:
```bash
node bot.js
```

O bot enviará alertas de arbitragem para seu Telegram sempre que detectar uma diferença significativa de preços.
